Adjacency_mat = TS_Func_Adjacency(input_mat,Density); % binarization
UBNIN_val = TS_Func_UBNIN(Adjacency_mat); % UBNIN computation
% input_mat: association/ weighted correlation matrix,
% Density: enter in percentage eg. 30. at which consistency-based threshold is to be calculated
N = 10; % matrix size
sample = 100000;
for i = 1:sample
    ub = randi([0 1],N,N); % binary matrix
    UBNIN(i) = TS_Func_UBNIN(ub); % UBNIN computation
end
unique_network = nnz(unique(UBNIN)) % number of unique networks